public class HistoricoProduto implements Historico {

    public String emitir() {
        return "Histórico de Produto";
    }
}
