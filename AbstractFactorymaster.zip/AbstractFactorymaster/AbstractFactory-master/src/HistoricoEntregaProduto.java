public class HistoricoEntregaProduto implements Historico {

    public String emitir() {
        return "Histórico de Entrega de Produto";
    }
}
