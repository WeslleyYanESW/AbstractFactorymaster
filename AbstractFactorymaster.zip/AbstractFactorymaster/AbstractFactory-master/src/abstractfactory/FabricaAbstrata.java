package abstractfactory;

public interface FabricaAbstrata {

    Mercado createMercado();

    Historico createHistorico();
}
