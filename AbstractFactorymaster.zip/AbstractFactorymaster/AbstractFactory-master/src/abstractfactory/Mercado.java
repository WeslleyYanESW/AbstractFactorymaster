package abstractfactory;

public class Mercado {

    private Mercado mercado;
    private Historico historico;

    public Mercado() {
        this.mercado = fabrica.createMercado();
        this.historico = fabrica.createHistorico();
    }

    public String emitirMercado() {
        return this.mercado.emitir();
    }

    public String emitirHistorico() {
        return this.historico.emitir();
    }


}