package abstractfactory;

public class FabricaMercado implements FabricaAbstrata {

    @Override
    public Empresa createMercado() {
        return new Mercado();
    }

    @Override
    public Historico createHistorico() {
        return new HistoricoProduto();
    }
}
