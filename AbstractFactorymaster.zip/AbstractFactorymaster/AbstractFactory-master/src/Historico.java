public interface Historico {

    String emitir();
}
