package padroescriacao.abstractfactory;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MercadoTest {

    @Test
    void deveEmitirHistoricoProduto() {
        FabricaAbstrata fabrica = new FabricaProduto();
        Mercado mercado = new Mercado(fabrica);
        assertEquals("Histórico de Produto", mercado.emitirHistorico());
    }

    @Test
    void deveEmitirHistoricoEstoqueProduto() {
        FabricaAbstrata fabrica = new FabricaEstoqueProduto();
        Mercado mercado = new Mercado(fabrica);
        assertEquals("Histórico de Estoque de Produto", mercado.emitirHistorico());
    }


}